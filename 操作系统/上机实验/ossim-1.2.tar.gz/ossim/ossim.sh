#!/bin/sh 
# 
# Shell script to launch OS sim on Unix systems.  
java -jar  ossim.jar 
